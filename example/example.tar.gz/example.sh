#!/bin/bash

echo "This is an example Spin plugin!"